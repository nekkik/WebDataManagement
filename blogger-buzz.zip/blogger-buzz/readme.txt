=== blogger buzz ===

Contributors: sparklewpthemes
Tags: one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, post-formats, sticky-post, theme-options, translation-ready, featured-images, e-commerce, blog, news
Requires at least: 4.7
Tested up to: 5.2.1
Requires PHP: 5.3.1
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Blogger Buzz is a user-friendly, feature-rich simple and clean, modern, stylish and beautiful fully customizable responsive free WordPress blog theme, Blogger Buzz theme can be fully utilized to develop awesome and modern websites for bloggers or related other business like fashion bloggers, lifestyle blogging, travel bloggers, personal blogging, music band & singers, photographers, writers, fashion designer, interior designers, wedding, eCommerce and many more bloggers people. Blogger Buzz free WordPress Blog theme is one of the most accessible themes which can easily accommodate all type of users with no coding skills normal to advanced WordPress developers. Blogger Buzz is completely built on Customizer options panel which allows you to customize theme settings easily with live previews interface. Blogger Buzz free WordPress Blog theme includes excellent features like ( Banner Post Slider, Display Features Posts, with 6 different posts display layout for ( index, category ) page also include one-click sample demo data import options with page and posts layout settings(Left, Right, Full Width), etc. which help to develop a simple, clean and modern website. Blogger Buzz free WordPress Blog theme is fully responsive, cross-browser compatible, translation ready, SEO friendly theme, also compatible with different external plugins like (WooCommerce, Jetpack, Contact Form 7, elementor page builder) and many more.

== Description ==

Blogger Buzz is a user-friendly, feature-rich simple and clean, modern, stylish and beautiful fully customizable responsive free WordPress blog theme, Blogger Buzz theme can be fully utilized to develop awesome and modern websites for bloggers or related other business like fashion bloggers, lifestyle blogging, travel bloggers, personal blogging, music band & singers, photographers, writers, fashion designer, interior designers, wedding, eCommerce and many more bloggers people. Blogger Buzz free WordPress Blog theme is one of the most accessible themes which can easily accommodate all type of users with no coding skills normal to advanced WordPress developers. Blogger Buzz is completely built on Customizer options panel which allows you to customize theme settings easily with live previews interface. Blogger Buzz free WordPress Blog theme includes excellent features like ( Banner Post Slider, Display Features Posts, with 6 different posts display layout for ( index, category ) page also include one-click sample demo data import options with page and posts layout settings(Left, Right, Full Width), etc. which help to develop a simple, clean and modern website. Blogger Buzz free WordPress Blog theme is fully responsive, cross-browser compatible, translation ready, SEO friendly theme, also compatible with different external plugins like (WooCommerce, Jetpack, Contact Form 7, elementor page builder) and many more. If you face any problem related to our theme, you can refer to our theme documentation or contact our friendly support team. Check demo at http://demo.sparklewpthemes.com/bloggerbuzz/ and theme details at https://sparklewpthemes.com/wordpress-themes/bloggerbuzz and get free support forum at https://sparklewpthemes.com/support/



== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Translation ==

Blogger Buzz theme is translation ready.


== Frequently Asked Questions ==

= Does this theme support any plugins? =

Theme supports Jetpack, Contact Form 7, Elementor page builder, Page Builder by SiteOrigin and many more.

= Where can I find theme all features ? =

You can check our Theme features at http://sparklewpthemes.com/wordpress-themes/bloggerbuzz/

= Where can I find theme demo? =

You can check our Theme Demo at http://demo.sparklewpthemes.com/bloggerbuzz/


== Copyright ==

Blogger Buzz WordPress Theme, Copyright (C) 2018 Sparkle Themes.
Blogger Buzz is distributed under the terms of the GNU GPL


== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)

* Font Awesome Free 5.5.0 by @fontawesome - https://fontawesome.com
License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)

* Breadcrumbs Trail https://github.com/justintadlock/breadcrumb-trail, Copyright and License : Breadcrumb Trail is licensed under the GNU GPL, version 2 or later, 2008 – 2015 © Justin Tadlock.

* Owl Carousel v2.3.4. Copyright 2013-2018 David Deutsch
Licensed under: SEE LICENSE IN https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE

* Bootstrap v4.3.0 (https://getbootstrap.com/). Copyright 2011-2019 The Bootstrap Authors. Copyright 2011-2019 Twitter, Inc.
Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

* lightslider - v1.1.6 - 2016-10-25. https://github.com/sachinchoolur/lightslider
Copyright (c) 2016 Sachin N; Licensed MIT.

* Theia Sticky Sidebar v1.6.0. https://github.com/WeCodePixels/theia-sticky-sidebar. Copyright 2013-2016 WeCodePixels and other contributors. Released under the MIT license.

* Sticky Plugin v1.0.4 for jQuery. Author: Anthony Garand. Improvements by German M. Bravo (Kronuz) and Ruud Kamphuis (ruudk). Improvements by Leonardo C. Daronco (daronco)., Created: 02/14/2011,  http://stickyjs.com/

* Slider Images One - https://pxhere.com/en/photo/1169780
License: CCO (https://pxhere.com/en/license)

* Slider Images Two - https://pxhere.com/en/photo/1543007
License: CCO (https://pxhere.com/en/license)

* Slider Images Three - https://pxhere.com/en/photo/1523587
License: CCO (https://pxhere.com/en/license)

* Features Post Images - https://pxhere.com/en/photo/40078
License: CCO (https://pxhere.com/en/license)

* Features Post Images - https://pxhere.com/en/photo/1026149
License: CCO (https://pxhere.com/en/license)


== Changelog ==

= 1.0.1 15th July 2019 =

** Add the Upgrade PRO version button link and information.
** Add one click import demo data.
** Update .pot file.


= 1.0.0 - June 09th 2019 =

* Initial release
